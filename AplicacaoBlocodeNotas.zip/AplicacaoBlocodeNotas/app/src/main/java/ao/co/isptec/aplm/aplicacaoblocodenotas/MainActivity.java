package ao.co.isptec.aplm.aplicacaoblocodenotas;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<String> noteTitles;
    ArrayList<String> noteContents = new ArrayList<>(); // Armazenar os conteúdos das notas

    ArrayAdapter<String> adapter;
    ListView listView;
    Button newNoteButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        noteTitles = new ArrayList<>();
        listView = findViewById(R.id.listView);
        newNoteButton = findViewById(R.id.newNoteButton);

        // Adapter para mostrar os títulos das notas na lista
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, noteTitles);
        listView.setAdapter(adapter);

        newNoteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Abrir a atividade para criar uma nova nota
                Intent intent = new Intent(MainActivity.this, CreateNote.class); // Corrigir nome da classe
                startActivityForResult(intent, 1);
            }
        });

        listView.setOnItemClickListener((parent, view, position, id) -> {
            // Abrir a atividade para ler uma nota selecionada
            Intent intent = new Intent(MainActivity.this, ReadNoteActivity.class);
            intent.putExtra("noteTitle", noteTitles.get(position));
            intent.putExtra("noteContent", noteContents.get(position)); // Passar o conteúdo também
            startActivity(intent);
        });

        // Aplicar insets para manter compatibilidade com os gestos de navegação (Edge-to-Edge)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK) {
            String title = data.getStringExtra("noteTitle");
            String content = data.getStringExtra("noteContent");

            // Adicionar o título e o conteúdo da nota às respectivas listas
            noteTitles.add(title);
            noteContents.add(content); // Adicionar o conteúdo da nota
            adapter.notifyDataSetChanged();
        }
    }
}
