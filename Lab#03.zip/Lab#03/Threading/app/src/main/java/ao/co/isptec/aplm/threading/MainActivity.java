package ao.co.isptec.aplm.threading;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.annotation.WorkerThread;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "ThreadingApp";
    private Button startButton, stopButton;
    private WorkerThread workerThread;
    private boolean running;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        startButton = findViewById(R.id.button_start);
        stopButton = findViewById(R.id.button_stop);

        // Configurar o botão "Start"
        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startCounting();
            }
        });

        // Configurar o botão "Stop"
        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopCounting();
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    // Função para iniciar a contagem
    private void startCounting() {
        if (workerThread != null && workerThread.isAlive()) {
            workerThread.interrupt();
        }
        running = true;
        workerThread = new WorkerThread();
        workerThread.start();
    }

    // Função para parar a contagem
    private void stopCounting() {
        if (workerThread != null) {
            workerThread.interrupt();
            running = false;
        }
    }

    // Classe interna da Worker Thread
    private class WorkerThread extends Thread {
        private int counter = 0;

        @Override
        public void run() {
            while (running) {
                try {
                    Thread.sleep(1000); // Espera 1 segundo
                    counter++;
                    Log.d(TAG, "Contador: " + counter);
                } catch (InterruptedException e) {
                    Log.d(TAG, "Thread interrompida");
                    break; // Interrompe o ciclo ao ser interrompida
                }
            }
        }
    }
}