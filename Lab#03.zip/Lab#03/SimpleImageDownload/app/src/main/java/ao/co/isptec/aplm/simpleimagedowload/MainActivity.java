package ao.co.isptec.aplm.simpleimagedowload;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private static final String IMAGE_SOURCE = "https://via.placeholder.com/300.png";
    private Button btnDownloadFileAsync;
    private Button btnDownloadFileThread;
    private TextView statusTextView;
    private ImageView imageView;
    private Handler handler;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnDownloadFileAsync = findViewById(R.id.btnDownloadFileAsync);
        btnDownloadFileThread = findViewById(R.id.btnDownloadFile);
        imageView = findViewById(R.id.image_view);
        statusTextView = findViewById(R.id.status);

        // Inicializa o Handler para atualizar a interface na Thread principal
        handler = new Handler(Looper.getMainLooper(), new Handler.Callback() {
            @Override
            public boolean handleMessage(Message msg) {
                String status = msg.getData().getString("status");
                statusTextView.setText(status);

                Bitmap bitmap = msg.getData().getParcelable("bitmap");
                if (bitmap != null) {
                    imageView.setImageBitmap(bitmap);
                }
                return true;
            }
        });

        // Configuração do botão de download com AsyncTask
        btnDownloadFileAsync.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Inicia o AsyncTask para baixar a imagem
                new DownloadTask(imageView, statusTextView).execute(IMAGE_SOURCE);
            }
        });

        // Configuração do botão de download com Thread + Handler
        btnDownloadFileThread.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Inicia uma nova Thread para baixar a imagem
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        downloadImageWithThread(IMAGE_SOURCE);
                    }
                }).start();
            }
        });
    }

    // Método para download da imagem usando Thread + Handler
    private void downloadImageWithThread(String urlStr) {
        try {
            URL url = new URL(urlStr);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();

            // Verifica se a conexão foi bem-sucedida
            int responseCode = connection.getResponseCode();
            if (responseCode != HttpURLConnection.HTTP_OK) {
                sendMessageToHandler("Erro no servidor: " + responseCode, null);
                return;
            }

            InputStream input = connection.getInputStream();
            Bitmap image = BitmapFactory.decodeStream(input);
            if (image != null) {
                // Envia a imagem e a mensagem de sucesso para o Handler
                sendMessageToHandler("Download concluído com sucesso!", image);
            } else {
                // Envia a mensagem de falha para o Handler
                sendMessageToHandler("Falha no download: erro ao decodificar a imagem.", null);
            }
        } catch (Exception e) {
            e.printStackTrace();
            // Envia a mensagem de falha para o Handler
            sendMessageToHandler("Falha no download: " + e.getMessage(), null);
        }
    }

    // Método para enviar uma mensagem ao Handler
    private void sendMessageToHandler(String status, Bitmap bitmap) {
        Message message = handler.obtainMessage();
        Bundle data = new Bundle();
        data.putString("status", status);
        if (bitmap != null) {
            data.putParcelable("bitmap", bitmap);
        }
        message.setData(data);
        handler.sendMessage(message);
    }

    // Classe AsyncTask para fazer o download da imagem
    private static class DownloadTask extends AsyncTask<String, Void, Bitmap> {
        private final ImageView imageView;
        private final TextView statusText;

        public DownloadTask(ImageView imageView, TextView statusText) {
            this.imageView = imageView;
            this.statusText = statusText;
        }

        @Override
        protected void onPreExecute() {
            // Antes de começar o download, atualiza o status para "Baixando..."
            statusText.setText("Download iniciado...");
        }

        @Override
        protected Bitmap doInBackground(String... inputUrls) {
            String urlStr = inputUrls[0];
            Bitmap image = null;
            try {
                URL url = new URL(urlStr);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setDoInput(true);
                connection.connect();

                // Verifica se a conexão foi bem-sucedida
                int responseCode = connection.getResponseCode();
                if (responseCode != HttpURLConnection.HTTP_OK) {
                    throw new Exception("Erro no servidor: " + responseCode);
                }

                InputStream input = connection.getInputStream();
                image = BitmapFactory.decodeStream(input);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return image;
        }

        @Override
        protected void onPostExecute(Bitmap result) {
            // Atualiza a imagem no ImageView se o download foi bem-sucedido
            if (result != null) {
                imageView.setImageBitmap(result);
                statusText.setText("Download concluído com sucesso!");
            } else {
                statusText.setText("Falha no download.");
            }
        }
    }
}
