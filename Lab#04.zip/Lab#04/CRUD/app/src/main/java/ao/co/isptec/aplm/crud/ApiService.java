package ao.co.isptec.aplm.crud;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.*;

    public interface ApiService {
        @GET("/employees")
        Call<List<User>> getUsers();

        @POST("/employees")
        Call<User> createUser(@Body User user);

        @PUT("/employees/{id}")
        Call<User> updateUser(@Path("id") int id, @Body User user);

        @DELETE("/employees/{id}")
        Call<Void> deleteUser(@Path("id") int id);
    }

