package ao.co.isptec.aplm.broadcastreceivers;

import static android.content.ContentValues.TAG;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;
import android.util.Log;

public class MyPhoneReciever extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        // TODO: This method is called when the BroadcastReceiver is receiving
        // an Intent broadcast.

       /* if(intent.getAction() == TelephonyManager.ACTION_PHONE_STATE_CHANGED){
            String state = intent.getStringExtra(TelephonyManager.EXTRA_STATE);
            String number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER);
            Log.i(TAG, "State: " + state + ", Number: " + number);
        }*/

        // Verifica se a intenção contém a ação de telefone
        if (intent.getAction().equals(TelephonyManager.ACTION_PHONE_STATE_CHANGED)) {
            // Obtém o estado do telefone
            String state = intent.getStringExtra(TelephonyManager.EXTRA_STATE);

            // Verifica se o estado é de uma chamada recebida
            if (TelephonyManager.EXTRA_STATE_RINGING.equals(state)) {
                // Obtém o número do chamador
                String incomingNumber = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER);

                // Registra o estado da chamada e o número do chamador
                Log.i("MyPhoneReceiver", "Chamada recebida de: " + incomingNumber);
            }
        }
    }
}